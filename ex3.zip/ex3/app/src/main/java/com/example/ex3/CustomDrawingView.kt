package com.example.ex3

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class CustomDrawingView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private val paint = Paint()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Smooth edges
        paint.isAntiAlias = true

        // 1. Draw Circle
        paint.color = Color.RED
        paint.style = Paint.Style.FILL
        canvas.drawCircle(300f, 300f, 100f, paint)

        // 2. Draw Ellipse
        paint.color = Color.BLUE
        val oval = RectF(500f, 100f, 800f, 300f)
        canvas.drawOval(oval, paint)

        // 3. Draw Rectangle
        paint.color = Color.GREEN
        canvas.drawRect(100f, 500f, 500f, 700f, paint)

        // 4. Draw Text
        paint.color = Color.BLACK
        paint.textSize = 60f
        canvas.drawText("Hello from Canvas!", 100f, 850f, paint)
    }
}
